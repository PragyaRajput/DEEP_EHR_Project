
from django.contrib import admin
from django.urls import path
from testApp.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',index,name='Home_Page'),
    path('prediction_page/',prediction_page,name='prediction_page'),
    path('login',Login,name='login'),
    path('signup',Signup,name='signup'),
    path('Disease_prediction',Disease_prediction,name='Disease_prediction'),
    path('Disease_prediction1',Disease_prediction1,name='Disease_prediction1'),
    path('Disease_prediction2',Disease_prediction2,name='Disease_prediction2'),
    path('prediction_page1',prediction_page1,name='prediction_page1')

]
