# from django.http.request import HttpRequest
from django.shortcuts import render
from django.http import HttpResponse
import os
import yaml
import pickle as pk
from django.views.decorators.csrf import csrf_exempt
import joblib as jb
import numpy as np
import pandas as pd

params_path = "params.yaml"
webapp_root = "webapp"



def index(request):
    return render(request,'index.html')


def read_params(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
    return config


def predict(data):
    config = read_params(params_path)
    model_dir_path = config['webapp_model_dir']
    model = jb.load(model_dir_path)
    prediction = model.predict(data)

    # print("tttt")
    # print(prediction[0])
    # print(type(prediction[0]))
    return str(prediction[0])



def api_response(request):
    try:
        data = np.array([list(request.json.values())])
        response = predict(data)
        response = {"response":response}
        return response
    except Exception as e:
        print(e)
        error= {"error": "something went wrong!!! Try again"}
        return error



# Create your views here

def prediction_page(request):
    response=None
    dict ={}
    if request.method=="POST":
        dict['Age'] = request.POST['Age'] 
        dict['Gender'] = request.POST['Gender']  
        dict['RespiratoryRate_Max'] = request.POST['RespiratoryRate_Max']  
        dict['Temperature_Max'] = request.POST['Temperature_Max']  
        dict['RespiratoryRate_Min'] = request.POST['RespiratoryRate_Min']  
        dict['DiastolicBP_Std'] = request.POST['DiastolicBP_Std']  
        dict['BMI_Mean'] = request.POST['BMI_Mean']  
        dict['RespiratoryRate_Mean'] = request.POST['RespiratoryRate_Mean']  
        dict['Temperature_Mean'] = request.POST['Temperature_Mean']  
        dict['BMI_Change'] = request.POST['BMI_Change']  
        dict['DiastolicBP_Change'] = request.POST['DiastolicBP_Change']  
        dict['Height_Change'] = request.POST['Height_Change']  
        dict['RespiratoryRate_Change'] = request.POST['RespiratoryRate_Change']  
        dict['SystolicBP_Change'] = request.POST['SystolicBP_Change']  
        dict['Temperature_Change'] = request.POST['Temperature_Change']  
        dict['Weight_Change'] = request.POST['Weight_Change']
        data = dict.values()
        data = [list(map(float, data))]
        response = predict(data)
    return render(request,'prediction_page.html',{"response":response})

def Login(request):
    return render(request,'Login.html')

def Signup(request):
    return render(request,'SignUp.html')

# def Disease_prediction(request):
#     return render(request,'Disease_prediction.html')
def Disease_prediction(request):
    context = {}
    system = request.POST.get('system',None)
    context['system'] = system
    return render(request , 'prediction_page.html' , context)

def Disease_prediction1(request):
    context = {}
    system = request.POST.get('system',None)
    context['system'] = system
    return render(request ,'stroke_prediction_page.html' , context)
def Disease_prediction2(request):
    context = {}
    system = request.POST.get('system',None)
    context['system'] = system
    return render(request, 'heart_prediction_page.html', context)

config = read_params(params_path)
config_preprocessor = config['preprocessor_pickle']['preprocessor1']
print(config_preprocessor)
model_dir_path1 = config['webapp_model_dir1']
final_csv = config['data_source']['s3_bucket_stroke']
preprocessor_k1 = pk.load(open(config_preprocessor, 'rb'))
linear_svc11 = pk.load(open(model_dir_path1, 'rb'))

du = pd.read_csv(final_csv, parse_dates=['Visiting_Date'])
# preprocessor_k1 = pk.load(open('F:\EHR_final\EHR_Analysis\preprocessor_pickle\preprocessor_k.pkl', 'rb'))
# linear_svc11 = pk.load(open('F:\EHR_final\EHR_Analysis\prediction_service\model\linear_svc1.pkl', 'rb'))
# du = pd.read_csv('F:\EHR_final\EHR_Analysis\data_given\Final.csv', parse_dates=['Visiting_Date'])

# Create your views here.
@csrf_exempt
def prediction_page1(request):
    if request.method == 'POST':
        Sex = str(request.POST['gender'])
        Age = int(request.POST['Age'])
        BP = str(request.POST['Blood Pressure'])
        Cholesterol = str(request.POST['Cholesterol'])
        Smoking = str(request.POST['Smoking'])
        AF = str(request.POST['Atrial Fibrillation'])
        stroke_hist = str(request.POST['Family history of stroke'])
        BMI = str(request.POST['BMI'])
        Exercise = str(request.POST['Exercise'])
        DB_Fasting = str(request.POST['Diabetes_Fasting'])
        DB_After_Eating = str(request.POST['Diabetes_After_Eating'])
        Patient_id = 500
        x_k = csv_mapping(du)
        kk = Current_symptoms(Patient_id, Sex, Age, BP, Cholesterol, Smoking, AF, Exercise, stroke_hist, BMI,
                              DB_Fasting, DB_After_Eating, x_k)
        response=risk_advise(kk)
        return render(request,'stroke_prediction_page.html',{'response':response})


def return_categoricals(df, threshold=5):
    return list(filter(lambda c: c if len(df[c].unique()) <= threshold else None, df.columns))


def to_categorical(columns, df):
    for col in columns:
        df[col] = df[col].astype('category')
    return df

def csv_mapping(du):
    du['Sex'] = du['Sex'].map({'Male': 1, 'Female': 0})
    du['Blood Pressure'] = du['Blood Pressure'].map({'140/90 & Higher': 2, '120-139 / 80-89': 1, 'Less than 120/80': 0})
    du['Cholesterol'] = du['Cholesterol'].map({'Greater than 240': 2, '200 - 239': 1, 'Less than 200': 0})
    du['Smoking'] = du['Smoking'].map({'Yes': 2, 'Trying to Quit': 1, 'No': 0})
    du['Atrial Fibrillation'] = du['Atrial Fibrillation'].map(
        {'Irregular heartbeat': 2, 'heartbeat occasionally skips': 1, 'Normal Heartbeat': 0})
    du['Exercise'] = du['Exercise'].map({'Couch potato': 2, 'Exercise occasionally': 1, 'Exercise regularly': 0})
    du['Family history of stroke'] = du['Family history of stroke'].map({'Yes': 2, 'Not sure': 1, 'No': 0})
    du['BMI'] = du['BMI'].map({'Overweight(above 28)': 2, 'Slightly overweight(25-28)': 1, 'Healthy(18.5-24.9)': 0})
    du['Diabetes(Fasting)'] = du['Diabetes(Fasting)'].map(
        {'Above 126 mg/dL': 2, '100-125 mg/dL': 1, '99 mg/dL or below': 0})
    du['Diabetes(2-3 After Eating)'] = du['Diabetes(2-3 After Eating)'].map(
        {'200 mg/dL': 2, '140-199 mg/dL': 1, '140 mg/dL or below': 0})
    du['Stoke'] = du['Stoke'].map({'High_Risk': 2, 'Caution': 1, 'Low_Risk': 0})
    to_cast = return_categoricals(du, threshold=3)
    du = to_categorical(to_cast, du)
    x_k = du[du.columns[~du.columns.isin(['Visiting_Date', 'Stoke'])]]
    return (x_k)


def processed_df(Patient_id, Gender, Age, BP, Cholesterol, Smoking, AF, Exercise, stroke_hist, BMI, DB_Fasting,
                 DB_After_Eating, x_k):
    Sex = pd.Series(Gender).map({'Male': 1, 'Female': 0}).values[0]
    BP = pd.Series(BP).map({'140/90 & Higher': 2, '120-139 / 80-89': 1, 'Less than 120/80': 0}).values[0]
    Cholesterol = pd.Series(Cholesterol).map({'Greater than 240': 2, '200 - 239': 1, 'Less than 200': 0}).values[0]
    Smoking = pd.Series(Smoking).map({'Yes': 2, 'Trying to Quit': 1, 'No': 0}).values[0]
    AF = pd.Series(AF).map({'Irregular heartbeat': 2, 'heartbeat occasionally skips': 1, 'Normal Heartbeat': 0}).values[
        0]
    Exercise = pd.Series(Exercise).map({'Couch potato': 2, 'Exercise occasionally': 1, 'Exercise regularly': 0}).values[
        0]
    stroke_hist = pd.Series(stroke_hist).map({'Yes': 2, 'Not sure': 1, 'No': 0}).values[0]
    BMI = \
    pd.Series(BMI).map({'Overweight(above 28)': 2, 'Slightly overweight(25-28)': 1, 'Healthy(18.5-24.9)': 0}).values[0]
    DB_Fasting = pd.Series(DB_Fasting).map({'Above 126 mg/dL': 2, '100-125 mg/dL': 1, '99 mg/dL or below': 0}).values[0]
    DB_After_Eating = \
    pd.Series(DB_After_Eating).map({'Above 200 mg/dL': 2, '140-199 mg/dL': 1, '140 mg/dL or below': 0}).values[0]
    du1 = pd.DataFrame(columns=x_k.columns)
    du1.loc[0] = [Patient_id, Sex, Age, BP, Cholesterol, Smoking, AF, Exercise, stroke_hist, BMI, DB_Fasting,
                  DB_After_Eating]
    du1 = du1.astype(x_k.dtypes.to_dict())
    return (du1)


def Current_symptoms(Patient_id, Gender, Age, BP, Cholesterol, Smoking, AF, Exercise, stroke_hist, BMI, DB_Fasting,
                     DB_After_Eating, x_k):
    du = processed_df(Patient_id, Gender, Age, BP, Cholesterol, Smoking, AF, Exercise, stroke_hist, BMI, DB_Fasting,
                      DB_After_Eating, x_k)
    labels = ['Low_Risk', 'Caution', 'High_Risk']
    return linear_svc11.predict(preprocessor_k1.transform(du))[0]


def risk_advise(risk):
    a = {'High Risk': 'You are at High Risk to stroke. See your doctor about stroke prevention right away.',
         'Caution': 'Work with your doctor to decrease those risk factors you can change.',
         'Low Risk': "Congratulations! You're doing very well at controlling your risk for stroke!"}
    if risk == 2:
        return a['High Risk']
    elif risk == 1:
        return a['Caution']
    else:
        return a['Low Risk']
